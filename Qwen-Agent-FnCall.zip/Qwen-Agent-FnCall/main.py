import os
import sys
import json
from typing import (
    Dict,
    Optional,
    Union
)
from agents.fncall_agent import FnCallAgent
from tools.base import BaseTool, register_tool

llm_cfg = {'model': 'custom', 'api_base': 'http://192.168.102.7:9997/v1'}
function_list = ["UserDatabase"]
bot = FnCallAgent(function_list=function_list, llm=llm_cfg)

for response in bot.run(
        messages=[{'role': 'user', 'content': '职工张三的生日是在今年10月份吗？现在是2月份，距离张三的生日还有几个月？'}]
):
    print(response)
