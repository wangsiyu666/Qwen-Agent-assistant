from agents.assistant import Assistant
from llm.schema import ContentItem, Message


def assistant_system_and_tool():
    llm_cfg = {'model': 'custom', 'api_base': 'http://192.168.102.7:9997/v1'}
    system = '你扮演一个天气预报助手，你具有查询天气能力。并根据天气推荐一下穿搭'

    tools = ['open_weather']
    agent = Assistant(llm=llm_cfg, system_message=system, function_list=tools)

    messages = [Message('user', '铁岭天气如何？')]

    *_, last = agent.run(messages)

    # assert last[-3].function_call.name == 'open_weather'
    # assert last[-3].function_call.arguments == '{"location": "Shenyang"}'
    # assert last[-2].name == 'open_weather'
    # assert len(last[-1].content) > 0
    return last[-1].content


if __name__ == '__main__':
    r = assistant_system_and_tool()
    print(r)