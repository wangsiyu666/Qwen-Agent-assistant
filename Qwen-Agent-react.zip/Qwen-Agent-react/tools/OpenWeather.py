import os
from typing import (
    Dict,
    Optional,
    Union
)
import requests
from tools.base import BaseTool, register_tool


@register_tool('open_weather')
class OpenWeather(BaseTool):
    description = "获取对应城市的天气"
    parameters = [{
        'name': 'location',
        'type': 'string',
        'description': '城市/区具体名称，如`北京`请描述为`Beijing`',
        'required': True
    }]

    def __init__(self, cfg: Optional[Dict] = None):
        super().__init__(cfg)

        self.url = 'http://api.openweathermap.org/data/2.5/weather'
        import pandas as pd
        # 请设置api key免费申请的~~
        self.token = self.cfg.get('appid', os.environ.get('OpenWeather_TOKEN', 'f9e75241467f6d502905927ab800d699'))
        assert self.token != '', 'Open Weather token must be acquired though'

    def call(self, params: Union[str, dict], **kwargs) -> str:
        params = self._verify_json_format_args(params)
        location = params['location']
        para = {
            "q": location,
            "appid": self.token,
            "units": "metric",
            "lang": "zh_cn"
        }
        response = requests.get(
            self.url,
            params=para
        )
        result = response.json()
        return f"{location}的天气是{result['weather'][0]['description']} \n" \
               f"平均温度是: {result['main']['temp']}, 体感温度是 {result['main']['feels_like']} \n"

#
# if __name__ == '__main__':
#     para = {
#         "q": "shenyang",
#         "appid": "dawfawfwaff",
#         "units": "metric"
#     }
#     response = requests.get(
#         url='http://api.openweathermap.org/data/2.5/weather',
#         params=para
#     )
#     print(response.text)
