import os
import shutil
from pathlib import Path

from agents.react_chat import ReActChat
from llm.schema import ContentItem, Message
# import sys
# import os
#
# current_path = os.path.dirname(os.path.abspath(__file__))
# root_path = os.path.dirname(current_path)
# sys.path.append(root_path)
# print(sys.path)



def react_chat():
    llm_cfg = {'model': 'custom', 'api_base': 'http://192.168.102.7:9997/v1'}
    tools = ['open_weather']
    agent = ReActChat(llm=llm_cfg, function_list=tools)

    messages = [Message('user', '海淀区天气')]

    *_, last = agent.run(messages)

    # assert '\nAction: ' in last[-1].content
    # assert '\nAction Input: ' in last[-1].content
    # assert '\nObservation: ' in last[-1].content
    # assert '\nThought: ' in last[-1].content
    # assert '\nFinal Answer: ' in last[-1].content
    return last

def react_chat_with_file():
    if os.path.exists('workspace'):
        shutil.rmtree('workspace')
    llm_cfg = {
        'model': 'qwen-max',
        'model_server': 'dashscope',
        'api_key': os.getenv('DASHSCOPE_API_KEY'),
    }
    tools = ['code_interpreter']
    agent = ReActChat(llm=llm_cfg, function_list=tools)
    messages = [
        Message(
            'user',
            [
                ContentItem(
                    text=  # noqa
                    'pd.head the file first and then help me draw a line chart to show the changes in stock prices'),
                ContentItem(
                    file=str(Path(__file__).resolve().parent.parent.parent / 'examples/resource/stock_prices.csv'))
            ])
    ]

    *_, last = agent.run(messages)
    assert len(last[-1].content) > 0


if __name__ == '__main__':
    r = react_chat()
    print(r)

